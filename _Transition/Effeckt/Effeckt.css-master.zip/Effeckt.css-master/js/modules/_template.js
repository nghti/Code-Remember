var Effeckt = {

  init: function() {

    this.bindUIActions();

  },

  bindUIActions: function() {

    // event handlers

  },

  specificAction: function() {

  }

};

Effeckt.init();
